SBAN v19 newcomer demo

This bundle packages the SBAN v19 binary plus a starter script.

Quick start:
- Windows: double-click SBAN_v19_Start.bat
- Linux: run ./SBAN_v19_Start.sh

What to ask first:
- what is SBAN v19
- what makes it non-transformer
- does it learn while running
- what scores shipped
- what is the main caveat

Important benchmark caveat:
The packaged v19 numeric benchmark is self-seeded and transductive. The product demo here is a user-facing chat surface, not the numeric evaluation protocol.
