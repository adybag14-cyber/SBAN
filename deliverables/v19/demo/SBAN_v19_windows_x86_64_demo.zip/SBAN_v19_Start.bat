@echo off
setlocal
cd /d "%~dp0"
echo SBAN v19 newcomer demo
echo Press Enter on an empty line to exit.
echo.
:loop
set /p SBAN_PROMPT=You^> 
if "%SBAN_PROMPT%"=="" goto end
echo.
sban_v19.exe chat-demo "%SBAN_PROMPT%" 160 seed_path=data/sban_dialogue_seed_v19.txt
echo.
goto loop
:end
echo Demo finished.
pause
