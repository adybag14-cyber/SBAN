#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo "SBAN v19 newcomer demo"
echo "Press Enter on an empty line to exit."
while true; do
  printf 'You> '
  IFS= read -r SBAN_PROMPT || exit 0
  if [ -z "$SBAN_PROMPT" ]; then
    exit 0
  fi
  echo
  ./sban_v19 chat-demo "$SBAN_PROMPT" 160 seed_path=data/sban_dialogue_seed_v19.txt
  echo
done
