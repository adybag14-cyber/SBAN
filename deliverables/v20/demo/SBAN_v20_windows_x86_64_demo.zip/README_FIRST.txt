SBAN v20 newcomer demo

This bundle packages the SBAN v20 binary plus a starter script for a continuing chat session.

Quick start:
- Windows: double-click SBAN_v20_Start.bat
- Linux: run ./SBAN_v20_Start.sh

What to ask first:
- what is SBAN v20
- how do sessions work
- hi im tom
- can you recall my name
- what is 2 + 2
- what is the main caveat

Important benchmark caveat:
The packaged v20 numeric benchmark is self-seeded and transductive. The continuing chat demo here is a user-facing product surface, not the numeric evaluation protocol.
