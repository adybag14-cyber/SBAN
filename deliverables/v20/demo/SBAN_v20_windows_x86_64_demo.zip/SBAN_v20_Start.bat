@echo off
setlocal
cd /d "%~dp0"
if exist session_v20.txt del /f /q session_v20.txt
echo SBAN v20 continuing demo
echo Press Enter on an empty line to exit.
echo.
:loop
set /p SBAN_PROMPT=You^> 
if "%SBAN_PROMPT%"=="" goto end
echo.
sban_v20.exe chat-demo "%SBAN_PROMPT%" 160 mode=free seed_path=data/sban_dialogue_seed_v20.txt session_path=session_v20.txt
echo.
goto loop
:end
echo Demo finished.
pause
