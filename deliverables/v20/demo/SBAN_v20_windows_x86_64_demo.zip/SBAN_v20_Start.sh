#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
rm -f session_v20.txt
echo "SBAN v20 continuing demo"
echo "Press Enter on an empty line to exit."
while true; do
  printf 'You> '
  IFS= read -r SBAN_PROMPT || exit 0
  if [ -z "$SBAN_PROMPT" ]; then
    exit 0
  fi
  echo
  ./sban_v20 chat-demo "$SBAN_PROMPT" 160 mode=free seed_path=data/sban_dialogue_seed_v20.txt session_path=session_v20.txt
  echo
done
