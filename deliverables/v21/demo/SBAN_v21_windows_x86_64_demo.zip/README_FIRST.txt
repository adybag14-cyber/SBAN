SBAN v21 newcomer demo

This bundle packages the SBAN v21 binary plus a starter script for a continuing grounded chat session.

Quick start:
- Windows: double-click SBAN_v21_Start.bat
- Linux: run ./SBAN_v21_Start.sh

What to ask first:
- what is SBAN v21
- explain sparse bridge-adaptive network architecture
- compare SBAN to transformers in detail
- hi i am tom and i need help
- can you recall my name
- my favorite color is blue
- what is my favorite color
- what is 3.5 + 1.2
- tell me a joke

Runtime notes:
- the chat demo defaults to the grounded v21 flow with session persistence
- GPU retrieval acceleration is used automatically when a compatible OpenCL backend is present
- CPU fallback is automatic when no GPU path is available

Important benchmark caveat:
The packaged numeric v21 benchmark remains separate from this demo and must still be described according to the release methodology documented in the main repository.
