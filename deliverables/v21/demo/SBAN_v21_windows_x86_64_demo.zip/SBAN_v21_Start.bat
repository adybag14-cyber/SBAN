@echo off
setlocal
cd /d "%~dp0"
if exist session_v21.txt del /f /q session_v21.txt
echo SBAN v21 grounded continuing demo
echo GPU acceleration is used automatically when OpenCL is available.
echo Press Enter on an empty line to exit.
echo.
:loop
set /p SBAN_PROMPT=You^> 
if "%SBAN_PROMPT%"=="" goto end
echo.
sban_v21.exe chat-demo "%SBAN_PROMPT%" 160 seed_path=data/sban_dialogue_seed_v21.txt session_path=session_v21.txt backend=auto
echo.
goto loop
:end
echo Demo finished.
pause
