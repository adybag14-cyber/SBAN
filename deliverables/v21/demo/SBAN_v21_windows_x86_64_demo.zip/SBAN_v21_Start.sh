#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
rm -f session_v21.txt
echo "SBAN v21 grounded continuing demo"
echo "GPU acceleration is used automatically when OpenCL is available."
echo "Press Enter on an empty line to exit."
while true; do
  printf 'You> '
  IFS= read -r SBAN_PROMPT || exit 0
  if [ -z "$SBAN_PROMPT" ]; then
    exit 0
  fi
  echo
  ./sban_v21 chat-demo "$SBAN_PROMPT" 160 seed_path=data/sban_dialogue_seed_v21.txt session_path=session_v21.txt backend=auto
  echo
done
