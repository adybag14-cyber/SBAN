SBAN v22.5 newcomer demo

This bundle packages the SBAN v22.5 binary plus a starter script for a continuing grounded chat session.

Quick start:
- Windows: double-click SBAN_v22_5_Start.bat
- Linux: run ./SBAN_v22_5_Start.sh

What to ask first:
- what is SBAN v22.5
- how is v22.5 different from v22
- do you support nvidia rtx gpus
- how does cuda acceleration work
- when should i use cpu_mt
- hi i am tom and i need help
- can you recall my name

Runtime notes:
- the starter loop defaults to CPU for the small grounded product corpus
- use `sban_v22_5 accel-info seed_path=data/sban_dialogue_seed_v22.txt backend=cuda` to probe NVIDIA CUDA support
- use `backend=cpu_mt threads=4` or `backend=cuda` explicitly when you want to experiment with the accelerated retrieval paths

Important benchmark note:
The packaged numeric v22.5 suite stays on the proven single-thread release profile. The point release adds experimental multithreaded numeric scoring, but it is not the shipped default because the release-profile timings were neutral to slightly worse on the validation machine.
