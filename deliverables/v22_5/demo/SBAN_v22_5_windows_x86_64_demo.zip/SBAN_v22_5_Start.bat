@echo off
setlocal
cd /d "%~dp0"
if exist session_v22_5.txt del /f /q session_v22_5.txt
echo SBAN v22.5 grounded continuing demo
echo Default backend: CPU for the bundled grounded corpus.
echo Run "sban_v22_5.exe accel-info seed_path=data/sban_dialogue_seed_v22.txt backend=cuda" to inspect NVIDIA CUDA support.
echo Press Enter on an empty line to exit.
echo.
:loop
set /p SBAN_PROMPT=You^>
if "%SBAN_PROMPT%"=="" goto end
echo.
sban_v22_5.exe chat-demo "%SBAN_PROMPT%" 160 seed_path=data/sban_dialogue_seed_v22.txt session_path=session_v22_5.txt backend=cpu
echo.
goto loop
:end
echo Demo finished.
pause
