#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
rm -f session_v22_5.txt
echo "SBAN v22.5 grounded continuing demo"
echo "Default backend: CPU for the bundled grounded corpus."
echo "Run './sban_v22_5 accel-info seed_path=data/sban_dialogue_seed_v22.txt backend=cuda' to inspect NVIDIA CUDA support."
echo "Press Enter on an empty line to exit."
while true; do
  printf 'You> '
  IFS= read -r SBAN_PROMPT || exit 0
  if [ -z "$SBAN_PROMPT" ]; then
    exit 0
  fi
  echo
  ./sban_v22_5 chat-demo "$SBAN_PROMPT" 160 seed_path=data/sban_dialogue_seed_v22.txt session_path=session_v22_5.txt backend=cpu
  echo
done
