SBAN v23 newcomer demo

This bundle packages the SBAN v23 binary plus a starter script for a continuing grounded chat session with the real v23 dialogue seed.

Quick start:
- Windows: double-click SBAN_v23_Start.bat
- Linux: run ./SBAN_v23_Start.sh

What to ask first:
- what is SBAN v23
- what command shows cuda support
- what is the windows starter file called
- where is the v23 paper pdf
- can this run on an rtx 4090
- hi i am tom and i need help
- can you recall my name
- tell me a joke

Runtime notes:
- the starter loop defaults to CPU for the bundled grounded corpus
- the default chat loop is free mode with safe conversational composition enabled
- use `sban_v23 accel-info seed_path=data/sban_dialogue_seed_v23.txt backend=cuda` to probe NVIDIA CUDA support
- use `backend=cpu_mt threads=4` or `backend=cuda` explicitly when you want to experiment with the accelerated retrieval paths

Important benchmark note:
The packaged numeric v23 suite stays on the proven single-thread release profile. The release still includes experimental multithreaded numeric scoring, but it is not the shipped default because the release-profile timings have not yet shown a dependable win from forcing it.
