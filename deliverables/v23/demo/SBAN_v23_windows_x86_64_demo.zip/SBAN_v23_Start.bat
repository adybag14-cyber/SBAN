@echo off
setlocal
cd /d "%~dp0"
if exist session_v23.txt del /f /q session_v23.txt
echo SBAN v23 continuing demo
echo Default backend: CPU for the bundled grounded corpus.
echo Run "sban_v23.exe accel-info seed_path=data/sban_dialogue_seed_v23.txt backend=cuda" to inspect NVIDIA CUDA support.
echo Press Enter on an empty line to exit.
echo.
:loop
set /p SBAN_PROMPT=You^>
if "%SBAN_PROMPT%"=="" goto end
echo.
sban_v23.exe chat-demo "%SBAN_PROMPT%" 180 seed_path=data/sban_dialogue_seed_v23.txt session_path=session_v23.txt backend=cpu mode=free allow_generation=true
echo.
goto loop
:end
echo Demo finished.
pause
