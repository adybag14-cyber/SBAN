#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
rm -f session_v23.txt
echo "SBAN v23 continuing demo"
echo "Default backend: CPU for the bundled grounded corpus."
echo "Run './sban_v23 accel-info seed_path=data/sban_dialogue_seed_v23.txt backend=cuda' to inspect NVIDIA CUDA support."
echo "Press Enter on an empty line to exit."
while true; do
  printf 'You> '
  IFS= read -r SBAN_PROMPT || exit 0
  if [ -z "$SBAN_PROMPT" ]; then
    exit 0
  fi
  echo
  ./sban_v23 chat-demo "$SBAN_PROMPT" 180 seed_path=data/sban_dialogue_seed_v23.txt session_path=session_v23.txt backend=cpu mode=free allow_generation=true
  echo
done
