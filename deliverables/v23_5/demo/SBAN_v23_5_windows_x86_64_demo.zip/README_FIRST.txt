SBAN v23.5 newcomer demo

This bundle packages the SBAN v23.5 binary plus a starter script for a continuing grounded chat session with the real v23.5 dialogue seed.

Quick start:
- Windows: double-click SBAN_v23_5_Start.bat
- Linux: run ./SBAN_v23_5_Start.sh

What to ask first:
- what is SBAN v23.5
- what command shows cuda support
- what command shows numeric cuda support
- what is the windows starter file called
- where is the v23.5 paper pdf
- can this run on an rtx 4090
- hi i am tom and i need help
- can you recall my name
- tell me a joke

Runtime notes:
- the starter loop defaults to CPU for the bundled grounded corpus
- the default chat loop is free mode with safe conversational composition enabled
- use `sban_v23_5 accel-info seed_path=data/sban_dialogue_seed_v23_5.txt backend=cuda` to probe NVIDIA CUDA retrieval support
- use `sban_v23_5 numeric-accel-info numeric_backend=cuda cuda_min_scoring_edges=1` to probe the numeric CUDA backend
- use `backend=cpu_mt threads=4` or `backend=cuda` explicitly when you want to experiment with the accelerated retrieval paths

Important benchmark note:
The packaged numeric v23.5 suite still stays on the proven single-thread CPU release profile. The release adds experimental numeric cpu_mt and CUDA backends, but they are not the shipped default unless the measured release-profile timings earn that promotion.
