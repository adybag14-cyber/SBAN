SBAN v24 newcomer demo

This bundle packages the SBAN v24 binary plus a starter script for a continuing chat session that uses both the grounded v24 seed and the separate v24 open-chat seed.

Quick start:
- Windows: double-click SBAN_v24_Start.bat
- Linux: run ./SBAN_v24_Start.sh

What to ask first:
- what is SBAN v24
- what files ship in the bundle
- what command shows cuda support
- can this run on an rtx 4090
- hi i am tom and i need help
- can you recall my name
- i am from london
- where am i from
- can you help me plan tomorrow
- what should i do this weekend

Runtime notes:
- the starter loop uses backend=auto with both the grounded and open-chat v24 seeds loaded
- the default chat loop is free mode with safe conversational composition enabled
- use `sban_v24 accel-info seed_path=data/sban_dialogue_seed_v24.txt backend=cuda` to probe NVIDIA CUDA retrieval support
- use `sban_v24 numeric-accel-info numeric_backend=cuda cuda_min_scoring_edges=1` to probe the numeric CUDA backend
- use `backend=cpu_mt threads=4` or `backend=cuda` explicitly when you want to override the hybrid retrieval path

Important product note:
SBAN v24 is much broader in free chat than v23, but it is still not a broad general knowledge model. It should answer grounded SBAN questions, remembered session facts, short math, and a wider set of ordinary conversational prompts well, while still declining unsupported factual questions honestly.
