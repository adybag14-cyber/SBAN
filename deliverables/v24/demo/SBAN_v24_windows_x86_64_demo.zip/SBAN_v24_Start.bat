@echo off
setlocal
cd /d "%~dp0"
if exist session_v24.txt del /f /q session_v24.txt
echo SBAN v24 continuing demo
echo Default backend: auto. The bundled chat loop uses both the grounded and open-chat v24 seeds.
echo Run "sban_v24.exe accel-info seed_path=data/sban_dialogue_seed_v24.txt backend=cuda" to inspect NVIDIA CUDA support.
echo Run "sban_v24.exe numeric-accel-info numeric_backend=cuda cuda_min_scoring_edges=1" to inspect the numeric CUDA backend.
echo Press Enter on an empty line to exit.
echo.
:loop
set /p SBAN_PROMPT=You^>
if "%SBAN_PROMPT%"=="" goto end
echo.
sban_v24.exe chat-demo "%SBAN_PROMPT%" 180 seed_path=data/sban_dialogue_seed_v24.txt open_seed_path=data/sban_dialogue_open_seed_v24.txt session_path=session_v24.txt backend=auto mode=free allow_generation=true
echo.
goto loop
:end
echo Demo finished.
pause
