# SBAN Hybrid Backend Recommendation

- Small shipped seed with `backend=auto`: `cpu`
- Large retrieval bench best backend: `cuda`
- Numeric release-profile recommendation: `numeric_backend=cpu score_threads=1`

## Summary
- Use backend=auto for dialogue retrieval so SBAN can stay on CPU for the small shipped seed and promote to CUDA on larger NVIDIA-backed retrieval workloads.
- Keep the packaged numeric release path on numeric_backend=cpu unless the measured auto or cpu_mt path actually beats it on the release profile.
- Treat numeric_backend=cuda as explicit experimentation only until end-to-end release-profile timings beat CPU.
