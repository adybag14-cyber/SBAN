#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "docs" / "results" / "v24"
BIN = ROOT / "zig-out" / "bin" / ("zig_sban.exe" if os.name == "nt" else "zig_sban")

SEED_PATH = "data/sban_dialogue_seed_v23_5.txt"
PROMPT_PATH = "data/sban_chat_eval_prompts_v23_5.txt"

COMMON_PROFILE = [
    "enable_long_term=false",
    "history_lags=32",
    "birth_margin=21",
    "min_parents_for_birth=4",
    "max_carry_memories=48",
    "max_hidden_per_hop=32",
    "propagation_depth=2",
    "birth_pressure_threshold_bonus=0",
    "birth_saturation_threshold_bonus=0",
    "birth_saturation_parent_boost=0",
    "hybrid_share_ppm=0",
    "hybrid_recent_drift_bonus=0",
    "recent_markov2_bonus_ppm=0",
    "burst_bonus_ppm=520",
    "markov1_bonus_ppm=340",
    "markov2_bonus_ppm=760",
    "markov3_bonus_ppm=1900",
    "markov4_bonus_ppm=2400",
    "markov5_bonus_ppm=2800",
    "continuation_bonus_ppm=8000",
    "continuation_min_order=8",
    "continuation_max_order=32",
    "continuation_support_prior=0",
    "continuation_min_support=1",
    "hybrid_support_prior=0",
    "hybrid_evidence_prior=0",
]


def resolve_zig_exe(explicit: str | None) -> str:
    if explicit:
        return explicit
    if shutil.which("zig"):
        return shutil.which("zig")  # type: ignore[return-value]
    candidates = [
        Path.home() / "Documents" / "toolchains" / "zig-0.17.0-dev.87" / "zig_x86_64-windows-0.17.0-dev.87+9b177a7d2" / "zig.exe",
        Path.home() / "Documents" / "toolchains" / "zig-0.17.0-dev.87" / "zig-x86_64-windows-0.17.0-dev.87+9b177a7d2" / "zig.exe",
        Path.home() / "tools" / "zig-x86_64-windows-0.17.0-dev.87+9b177a7d2" / "zig.exe",
    ]
    for candidate in candidates:
        if candidate.exists():
            return str(candidate)
    raise FileNotFoundError("zig not found on PATH and no known local toolchain candidate exists")


def build_binary(zig_exe: str | None) -> None:
    subprocess.run([resolve_zig_exe(zig_exe), "build", "-Doptimize=ReleaseFast"], cwd=ROOT, check=True)


def parse_key_values(text: str) -> dict[str, str]:
    parsed: dict[str, str] = {}
    for line in text.splitlines():
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        parsed[key.strip()] = value.strip()
    return parsed


def run_capture(cmd: list[str], output_path: Path) -> str:
    text = subprocess.check_output(cmd, cwd=ROOT, text=True)
    output_path.write_text(text, encoding="utf-8")
    return text


def ensure_bench_assets() -> tuple[Path, Path]:
    bench_seed = RESULTS / "accel_seed_v24_hybrid.txt"
    bench_prompts = RESULTS / "accel_prompts_v24_hybrid.txt"
    if bench_seed.exists() and bench_prompts.exists():
        return bench_seed, bench_prompts
    seed_text = (ROOT / SEED_PATH).read_text(encoding="utf-8").strip() + "\n\n"
    prompt_lines = (ROOT / PROMPT_PATH).read_text(encoding="utf-8").strip().splitlines()
    bench_seed.write_text(seed_text * 200, encoding="utf-8")
    bench_prompts.write_text("\n".join(prompt_lines * 320) + "\n", encoding="utf-8")
    return bench_seed, bench_prompts


def measure_accel_backend(bench_seed: Path, bench_prompts: Path, backend_args: list[str], label: str) -> dict[str, float | int | str]:
    cmd = [
        str(BIN),
        "accel-bench",
        str(bench_prompts),
        *backend_args,
        f"seed_path={bench_seed}",
        "iterations=4",
    ]
    started = time.perf_counter()
    text = subprocess.check_output(cmd, cwd=ROOT, text=True)
    elapsed = time.perf_counter() - started
    parsed = parse_key_values(text)
    parsed["elapsed_seconds"] = f"{elapsed:.6f}"
    parsed["label"] = label
    return parsed


def measure_profile_variant(label: str, segment_len: int, seed_length: int, extra_overrides: list[str]) -> dict[str, float | int | str]:
    cmd = [
        str(BIN),
        "profile-variant",
        "data/enwik8",
        "prefix",
        "4",
        "default",
        str(segment_len),
        "5000",
        "4096",
        *COMMON_PROFILE,
        *extra_overrides,
        "sequence_seed_path=data/enwik8",
        "sequence_seed_offset=0",
        f"sequence_seed_length={seed_length}",
        f"profile_steps={segment_len * 4}",
    ]
    text = subprocess.check_output(cmd, cwd=ROOT, text=True)
    parsed = parse_key_values(text)
    parsed["label"] = label
    return parsed


def maybe_float(mapping: dict[str, float | int | str], key: str) -> float:
    return float(mapping[key])  # type: ignore[arg-type]


def build_recommendation(
    small_seed_auto: dict[str, str],
    retrieval: dict[str, dict[str, float | int | str]],
    numeric: dict[str, dict[str, float | int | str]],
) -> dict[str, object]:
    retrieval_best = min(
        (name for name in retrieval.keys()),
        key=lambda name: maybe_float(retrieval[name], "elapsed_seconds"),
    )
    numeric_best = min(
        (name for name in numeric.keys()),
        key=lambda name: maybe_float(numeric[name], "wall_seconds"),
    )

    numeric_release_default = "numeric_backend=cpu score_threads=1"
    numeric_cpu_wall = maybe_float(numeric["cpu_release"], "wall_seconds")
    numeric_auto_wall = maybe_float(numeric["auto_safe"], "wall_seconds")
    auto_uses_acceleration = (
        str(numeric["auto_safe"].get("cpu_mt_steps", "0")) != "0"
        or str(numeric["auto_safe"].get("cuda_steps", "0")) != "0"
    )
    if auto_uses_acceleration and numeric_auto_wall <= numeric_cpu_wall * 0.995:
        numeric_recommendation = "numeric_backend=auto score_threads=4 parallel_score_min_predictive_nodes=128"
    else:
        numeric_recommendation = numeric_release_default

    return {
        "small_seed_retrieval_auto_runtime": small_seed_auto.get("backend", "unknown"),
        "large_corpus_retrieval_best_backend": retrieval_best,
        "retrieval_recommended_command": "backend=auto",
        "numeric_best_profile_backend": numeric_best,
        "numeric_recommended_command": numeric_recommendation,
        "summary": [
            "Use backend=auto for dialogue retrieval so SBAN can stay on CPU for the small shipped seed and promote to CUDA on larger NVIDIA-backed retrieval workloads.",
            "Keep the packaged numeric release path on numeric_backend=cpu unless the measured auto or cpu_mt path actually beats it on the release profile.",
            "Treat numeric_backend=cuda as explicit experimentation only until end-to-end release-profile timings beat CPU.",
        ],
    }


def capture_nvidia_smi() -> str | None:
    if shutil.which("nvidia-smi") is None:
        return None
    try:
        return subprocess.check_output(
            ["nvidia-smi", "--query-gpu=name,driver_version", "--format=csv,noheader"],
            cwd=ROOT,
            text=True,
        ).strip()
    except subprocess.CalledProcessError:
        return None


def main() -> None:
    parser = argparse.ArgumentParser(description="Measure the best hybrid SBAN CPU/GPU backend mix on the current machine.")
    parser.add_argument("--zig-exe", help="Path to zig or zig.exe used for the build step.")
    parser.add_argument("--skip-build", action="store_true", help="Reuse the existing zig-out binary.")
    args = parser.parse_args()

    RESULTS.mkdir(parents=True, exist_ok=True)
    if not args.skip_build:
        build_binary(args.zig_exe)
    if not BIN.exists():
        raise FileNotFoundError(f"missing runtime binary: {BIN}")

    small_seed_auto = parse_key_values(
        run_capture(
            [str(BIN), "accel-info", f"seed_path={SEED_PATH}", "backend=auto"],
            RESULTS / "hybrid_small_seed_accel_info_auto.txt",
        )
    )

    bench_seed, bench_prompts = ensure_bench_assets()
    retrieval = {
        "cpu": measure_accel_backend(bench_seed, bench_prompts, ["backend=cpu"], "cpu"),
        "cpu_mt": measure_accel_backend(bench_seed, bench_prompts, ["backend=cpu_mt", "threads=4"], "cpu_mt"),
        "auto": measure_accel_backend(bench_seed, bench_prompts, ["backend=auto"], "auto"),
        "cuda": measure_accel_backend(bench_seed, bench_prompts, ["backend=cuda"], "cuda"),
    }

    numeric = {
        "cpu_release": measure_profile_variant("cpu_release", 62_500, 1_000_000, ["score_threads=1", "numeric_backend=cpu"]),
        "auto_safe": measure_profile_variant("auto_safe", 62_500, 1_000_000, ["score_threads=4", "numeric_backend=auto", "parallel_score_min_predictive_nodes=128"]),
        "cpu_mt_explicit": measure_profile_variant("cpu_mt_explicit", 62_500, 1_000_000, ["score_threads=4", "numeric_backend=cpu_mt", "parallel_score_min_predictive_nodes=1"]),
        "cuda_explicit": measure_profile_variant("cuda_explicit", 62_500, 1_000_000, ["score_threads=1", "numeric_backend=cuda", "cuda_min_scoring_edges=1"]),
    }

    recommendation = build_recommendation(small_seed_auto, retrieval, numeric)
    payload = {
        "small_seed_retrieval_auto": small_seed_auto,
        "retrieval_bench": retrieval,
        "numeric_release_profile": numeric,
        "recommendation": recommendation,
        "nvidia_smi": capture_nvidia_smi(),
    }

    (RESULTS / "hybrid_backend_v24.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    summary_lines = [
        "# SBAN Hybrid Backend Recommendation",
        "",
        f"- Small shipped seed with `backend=auto`: `{small_seed_auto.get('backend', 'unknown')}`",
        f"- Large retrieval bench best backend: `{recommendation['large_corpus_retrieval_best_backend']}`",
        f"- Numeric release-profile recommendation: `{recommendation['numeric_recommended_command']}`",
        "",
        "## Summary",
        *[f"- {line}" for line in recommendation["summary"]],  # type: ignore[index]
    ]
    (RESULTS / "hybrid_backend_v24.md").write_text("\n".join(summary_lines) + "\n", encoding="utf-8")
    print(RESULTS / "hybrid_backend_v24.json")


if __name__ == "__main__":
    main()
