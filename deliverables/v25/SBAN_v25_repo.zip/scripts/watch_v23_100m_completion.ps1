param(
    [Parameter(Mandatory = $true)]
    [string]$JsonPath,
    [Parameter(Mandatory = $true)]
    [string]$StatusPath,
    [int]$PollSeconds = 60
)

Add-Type -AssemblyName PresentationFramework

while ($true) {
    if (Test-Path $JsonPath) {
        try {
            $data = Get-Content -Raw -Path $JsonPath | ConvertFrom-Json
            $model = $data.models[0]
            $accuracy = 100.0 * [double]$model.total_correct / [double]$model.total_predictions
            $text = @"
completed=true
json_path=$JsonPath
accuracy_percent=$('{0:N4}' -f $accuracy)
total_predictions=$($model.total_predictions)
"@
            Set-Content -Path $StatusPath -Value $text -Encoding utf8
            [System.Windows.MessageBox]::Show(
                "SBAN v23 100M MT4 run completed.`nAccuracy: $('{0:N4}' -f $accuracy)%`nPredictions: $($model.total_predictions)",
                "SBAN v23 100M Complete"
            ) | Out-Null
        } catch {
            $errorText = @"
completed=false
json_path=$JsonPath
error=$($_.Exception.Message)
"@
            Set-Content -Path $StatusPath -Value $errorText -Encoding utf8
            [System.Windows.MessageBox]::Show(
                "SBAN v23 100M watcher hit an error while reading the result.`n$($_.Exception.Message)",
                "SBAN v23 100M Watcher Error"
            ) | Out-Null
        }
        break
    }
    Start-Sleep -Seconds $PollSeconds
}
