#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
rm -f session_v25.txt
echo "SBAN v25 continuing demo"
echo "Default backend: auto. The bundled chat loop uses both the grounded and open-chat v25 seeds."
echo "Run './sban_v25 accel-info seed_path=data/sban_dialogue_seed_v25.txt backend=cuda' to inspect NVIDIA CUDA support."
echo "Run './sban_v25 numeric-accel-info numeric_backend=cuda cuda_min_scoring_edges=1' to inspect the numeric CUDA backend."
echo "Press Enter on an empty line to exit."
while true; do
  printf 'You> '
  IFS= read -r SBAN_PROMPT || exit 0
  if [ -z "$SBAN_PROMPT" ]; then
    exit 0
  fi
  echo
  ./sban_v25 chat-demo "$SBAN_PROMPT" 180 seed_path=data/sban_dialogue_seed_v25.txt open_seed_path=data/sban_dialogue_open_seed_v25.txt session_path=session_v25.txt backend=auto mode=free allow_generation=true
  echo
done
