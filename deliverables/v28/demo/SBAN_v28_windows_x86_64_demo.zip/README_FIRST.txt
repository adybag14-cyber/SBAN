SBAN v28 newcomer demo

This bundle packages the SBAN v28 binary plus a starter script for a continuing chat session that uses both the grounded v28 seed and the separate v28 open-chat seed.

Quick start:
- Windows: double-click SBAN_v28_Start.bat
- Linux: run ./SBAN_v28_Start.sh

What to ask first:
- what is SBAN v28
- what files ship in the bundle
- what command shows cuda support
- can this run on an rtx 4090
- hi i am tom and i need help
- can you recall my name
- our team is atlas
- what team am i on
- i am from london
- where am i from
- my dog is luna
- what is my dog name
- my cat is io
- what is my cat name
- our project is nebula
- what project are we on
- remember that my launch date is tuesday
- when is my launch date
- can you help me plan tomorrow
- what should i do this weekend
- calculate 2^10
- translate hello to spanish
- summarize: SBAN v28 fixes stale labels and tightens eval matching
- what is json
- where is std.hashmap implemented in zig upstream

Runtime notes:
- the starter loop uses backend=auto with both the grounded and open-chat v28 seeds loaded
- the default chat loop is free mode with safe conversational composition enabled
- use `sban_v28 accel-info seed_path=data/sban_dialogue_seed_v28.txt backend=cuda` to probe NVIDIA CUDA retrieval support
- use `sban_v28 numeric-accel-info numeric_backend=cuda cuda_min_scoring_edges=1` to probe the numeric CUDA backend
- use `backend=cpu_mt threads=4` or `backend=cuda` explicitly when you want to override the hybrid retrieval path

Important product note:
SBAN v28 is broader and stricter than v27, but it is still not a broad general knowledge model. It should answer grounded SBAN questions, remembered session facts, short math, common practical coding and explanation prompts, and a wider set of ordinary conversational prompts well, while still declining or clearly bounding unsupported factual questions.
