SBAN v29 newcomer demo

This bundle packages the SBAN v29 binary plus a starter script for a continuing chat session that uses the grounded v29 seed, the open-chat seed, and the generated v29 synthetic knowledge pack.

Quick start:
- Windows: double-click SBAN_v29_Start.bat
- Linux: run ./SBAN_v29_Start.sh

What to ask first:
- what is SBAN v29
- what files ship in the bundle
- what command shows cuda support
- can this run on an rtx 4090
- hi i am tom and i need help
- can you recall my name
- our team is atlas
- what team am i on
- i am from london
- where am i from
- my dog is luna
- what is my dog name
- my cat is io
- what is my cat name
- our project is nebula
- what project are we on
- remember that my launch date is tuesday
- when is my launch date
- can you help me plan tomorrow
- what should i do this weekend
- calculate 2^10
- translate hello to spanish
- summarize: SBAN v29 fixes stale labels and tightens eval matching
- what is json
- where is std.hashmap implemented in zig upstream
- what causes tides
- what is mitosis
- who wrote pride and prejudice
- write a zig function to reverse a slice
- generate JSON with name and age
- solve 3x + 5 = 20
- calculate 2^1000

Runtime notes:
- the starter loop uses backend=auto with the grounded, open-chat, and synthetic-knowledge v29 assets loaded
- the default chat loop is free mode with safe conversational composition enabled
- use `sban_v29 accel-info seed_path=data/sban_dialogue_seed_v29.txt backend=cuda` to probe NVIDIA CUDA retrieval support
- use `sban_v29 numeric-accel-info numeric_backend=cuda cuda_min_scoring_edges=1` to probe the numeric CUDA backend
- use `backend=cpu_mt threads=4` or `backend=cuda` explicitly when you want to override the hybrid retrieval path

Important product note:
SBAN v29 adds a generated synthetic knowledge pack, wider Zig coding coverage, real-world task templates, and a larger-vocabulary probe. It is still a bounded static/offline runtime unless you supply a refreshed knowledge pack; it should answer from bundled knowledge and decline unsupported or live-current facts instead of inventing them.
