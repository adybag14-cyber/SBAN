@echo off
setlocal
cd /d "%~dp0"
if exist session_v34.txt del /f /q session_v34.txt
echo SBAN v34 continuing demo
echo Default backend: auto. The bundled chat loop loads the v34 runtime prewarm pack by default.
echo Run "sban_v34.exe accel-info backend=cuda" to inspect NVIDIA CUDA support.
echo Run "sban_v34.exe numeric-accel-info numeric_backend=cuda cuda_min_scoring_edges=1" to inspect the numeric CUDA backend.
echo Press Enter on an empty line to exit.
echo.
:loop
set /p SBAN_PROMPT=You^>
if "%SBAN_PROMPT%"=="" goto end
echo.
sban_v34.exe chat-demo "%SBAN_PROMPT%" 220 session_path=session_v34.txt backend=auto mode=free allow_generation=true
echo.
goto loop
:end
echo Demo finished.
pause
