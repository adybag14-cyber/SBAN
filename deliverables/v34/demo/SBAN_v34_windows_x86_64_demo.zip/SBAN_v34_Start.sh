#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
rm -f session_v34.txt
echo "SBAN v34 continuing demo"
echo "Default backend: auto. The bundled chat loop loads the v34 runtime prewarm pack by default."
echo "Run './sban_v34 accel-info backend=cuda' to inspect NVIDIA CUDA support."
echo "Run './sban_v34 numeric-accel-info numeric_backend=cuda cuda_min_scoring_edges=1' to inspect the numeric CUDA backend."
echo "Press Enter on an empty line to exit."
while true; do
  printf 'You> '
  IFS= read -r SBAN_PROMPT || exit 0
  if [ -z "$SBAN_PROMPT" ]; then
    exit 0
  fi
  echo
  ./sban_v34 chat-demo "$SBAN_PROMPT" 220 session_path=session_v34.txt backend=auto mode=free allow_generation=true
  echo
done
