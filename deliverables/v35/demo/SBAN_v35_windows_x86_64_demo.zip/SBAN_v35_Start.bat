@echo off
setlocal
cd /d "%~dp0"
if exist session_v35.txt del /f /q session_v35.txt
echo SBAN v35 continuing demo
echo Default backend: auto. The bundled chat loop loads the v35 runtime prewarm pack and learned reasoning corpus by default.
echo Run "sban_v35.exe accel-info backend=cuda" to inspect NVIDIA CUDA support.
echo Run "sban_v35.exe numeric-accel-info numeric_backend=cuda cuda_min_scoring_edges=1" to inspect the numeric CUDA backend.
echo Press Enter on an empty line to exit.
echo.
:loop
set /p SBAN_PROMPT=You^>
if "%SBAN_PROMPT%"=="" goto end
echo.
sban_v35.exe chat-demo "%SBAN_PROMPT%" 220 session_path=session_v35.txt backend=auto mode=free allow_generation=true
echo.
goto loop
:end
echo Demo finished.
pause
