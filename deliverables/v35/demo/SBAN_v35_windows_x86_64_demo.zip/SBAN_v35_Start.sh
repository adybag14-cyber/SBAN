#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
rm -f session_v35.txt
echo "SBAN v35 continuing demo"
echo "Default backend: auto. The bundled chat loop loads the v35 runtime prewarm pack and learned reasoning corpus by default."
echo "Run './sban_v35 accel-info backend=cuda' to inspect NVIDIA CUDA support."
echo "Run './sban_v35 numeric-accel-info numeric_backend=cuda cuda_min_scoring_edges=1' to inspect the numeric CUDA backend."
echo "Press Enter on an empty line to exit."
while true; do
  printf 'You> '
  IFS= read -r SBAN_PROMPT || exit 0
  if [ -z "$SBAN_PROMPT" ]; then
    exit 0
  fi
  echo
  ./sban_v35 chat-demo "$SBAN_PROMPT" 220 session_path=session_v35.txt backend=auto mode=free allow_generation=true
  echo
done
