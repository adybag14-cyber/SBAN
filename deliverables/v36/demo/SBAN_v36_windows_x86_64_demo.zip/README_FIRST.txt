SBAN v36 newcomer demo

This bundle packages the SBAN v36 binary plus a starter script for a continuing chat session. The runtime loads the generated v36 prewarm pack and learned reasoning corpus by default, so the starter loop does not need separate seed, open-seed, knowledge-path, or learned-path arguments.

Quick start:
- Windows: double-click SBAN_v36_Start.bat
- Linux: run ./SBAN_v36_Start.sh

What to ask first:
- what is SBAN v36
- how does SBAN v36 learn without editing dialogue.zig
- If all daxes are lums, and some lums are norps, are all daxes definitely norps? Explain.
- what is DNS
- what is entropy
- what does defer do in Zig
- write Python BFS for a graph
- how do I triage an outage
- what files ship in the bundle
- what command shows cuda support
- can this run on an rtx 4090
- hi i am tom and i need help
- can you recall my name
- our team is atlas
- what team am i on
- i am from london
- where am i from
- my dog is luna
- what is my dog name
- my cat is io
- what is my cat name
- our project is nebula
- what project are we on
- remember that my launch date is tuesday
- when is my launch date
- can you help me plan tomorrow
- what should i do this weekend
- calculate 2^10
- translate hello to spanish
- summarize: SBAN v36 fixes stale labels and tightens eval matching
- what is json
- where is std.hashmap implemented in zig upstream
- what causes tides
- what is mitosis
- who wrote pride and prejudice
- write a zig function to reverse a slice
- If no blickets are wugs and all glims are blickets, can any glim be a wug?
- solve x^2 = 4
- Sam has 14 apples, gives away 5, then buys 8. How many apples does Sam have?
- write a Rust async HTTP server
- generate JSON with name and age
- generate JSON with name Ada and age 37
- generate JSON with name Jane Doe and age 0
- forget my dog name
- solve 3x + 5 = 20
- calculate 2^1000

Runtime notes:
- the starter loop uses backend=auto with the generated v36 runtime prewarm pack and learned reasoning corpus loaded by default
- regenerate data/sban_learned_reasoning_v36.txt with scripts/build_v36_runtime_prewarm.py to improve learned replies from dataset adapters without editing dialogue.zig
- the default chat loop is free mode with safe conversational composition enabled
- use `sban_v36 accel-info backend=cuda` to probe NVIDIA CUDA retrieval support
- use `sban_v36 numeric-accel-info numeric_backend=cuda cuda_min_scoring_edges=1` to probe the numeric CUDA backend
- use `backend=cpu_mt threads=4` or `backend=cuda` explicitly when you want to override the hybrid retrieval path

Important product note:
SBAN v36 promotes the generated runtime prewarm pack and learned reasoning corpus to the default chat surface, fixes exact JSON slot preservation and session forget semantics, adds wider Zig/Rust and real-world task coverage, and probes larger vocabularies through 65,536 buckets. It is still a bounded static/offline runtime unless you supply refreshed knowledge; it should answer near-miss prompts with supported reasoning paths and reserve hard boundaries for live-current facts or missing external sources.
